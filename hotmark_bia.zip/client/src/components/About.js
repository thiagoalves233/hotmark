import { Link } from "react-router-dom";
const About = () => {
  return (
    <div>
      <h4>Versão 2.0.0</h4>
      <h5>BIA 15 a 21 de Maio/2023</h5>
      <Link to="/">Voltar</Link>
    </div>
  );
};

export default About;
